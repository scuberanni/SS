from django.contrib import admin
from . models import Scube_ss,orders


# Register your models here.
admin.site.register(Scube_ss)
admin.site.register(orders)